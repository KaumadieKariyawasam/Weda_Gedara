import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-spaowner-login',
  templateUrl: './spaowner-login.component.html',
  styleUrls: ['./spaowner-login.component.css']
})
export class SpaownerLoginComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
